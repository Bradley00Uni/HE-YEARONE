﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class colourChange : MonoBehaviour {

    Material mat;
    Renderer rend;

	void Start ()
    {
        mat = GetComponent<Renderer>().material;
	}



	void Update ()
    {
        if (Input.GetKey(KeyCode.Y))
        {
            mat.color = Color.yellow;
        }
        if (Input.GetKey(KeyCode.G))
        {
            mat.color = Color.green;
        }
        if (Input.GetKey(KeyCode.B))
        {
            mat.color = Color.blue;
        }
        if (Input.GetKey(KeyCode.R))
        {
            mat.color = Color.red;
        }
    }
}
