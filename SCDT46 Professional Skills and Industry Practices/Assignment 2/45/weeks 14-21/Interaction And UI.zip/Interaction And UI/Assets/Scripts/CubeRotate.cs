﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeRotate : MonoBehaviour {

    bool isSpinning = false;

    bool backwardsSpin = false;
    public void Rotation()
    {

        if(isSpinning)
        {

            isSpinning = false;
            
        }
        else
        {

            isSpinning = true;
            backwardsSpin = false;
        }
    }
	
    public void bRotate()
    {

        if(backwardsSpin)
        {

            backwardsSpin = false;

        }
        else
        {

            backwardsSpin = true;
            isSpinning = false;
        }
    }

	// Update is called once per frame
	void Update ()
    {
	
        if(isSpinning)
        {

            transform.Rotate(0.0f, 0.500f, 0.0f);

        }
        if(backwardsSpin)
        {

            transform.Rotate(0.0f, -0.500f, 0.0f);

        }
	}
}
