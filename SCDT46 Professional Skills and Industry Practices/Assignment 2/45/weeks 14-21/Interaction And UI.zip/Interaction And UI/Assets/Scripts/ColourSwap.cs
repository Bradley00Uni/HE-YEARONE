﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColourSwap : MonoBehaviour {

    // Use this for initialization

    Material mat;

    Renderer rend;

	void Start ()
    {

        mat = GetComponent<Renderer>().material;

	}
	
	// Update is called once per frame
	void Update ()
    {

        if (Input.GetKey(KeyCode.G))
        {

            mat.color = Color.green;

        }

        if (Input.GetKey(KeyCode.R))
        {

            mat.color = Color.red;

        }

        if (Input.GetKey(KeyCode.M))
        {

            mat.color = Color.magenta;

        }

        if (Input.GetKey(KeyCode.C))
        {

            mat.color = Color.cyan;

        }

        if (Input.GetKey(KeyCode.B))
        {

            mat.color = Color.black;

        }
    }
}
