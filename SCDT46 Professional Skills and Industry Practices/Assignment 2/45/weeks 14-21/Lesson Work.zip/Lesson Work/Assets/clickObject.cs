﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class clickObject : MonoBehaviour {

    // Update is called once per frame

    public GameObject Light;
    bool lightOn;

    void Start()
    {
        lightOn = true;  
    }

    void Update ()
    {
        if (Input.GetMouseButtonDown(0))
        {

        RaycastHit hit;

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        if(Physics.Raycast(ray, out hit, 100.0f))
        {
            if(hit.transform.name == "Switch")
            {
                    LightSwitch();
            }
        }
	}
    }
    void LightSwitch ()
    {
        switch (lightOn)
        {
            case true:
                Light.SetActive(false);
                lightOn = false;
                break;

            case false:
                Light.SetActive(true);
                lightOn = true;
                break;
        }
    } 

}
