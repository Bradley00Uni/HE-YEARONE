$('document').ready(function () {

    $('#p1').hide();
    $('#button1').click(function () {
        $('body').css('background-color', 'Hotpink')
    });

});
