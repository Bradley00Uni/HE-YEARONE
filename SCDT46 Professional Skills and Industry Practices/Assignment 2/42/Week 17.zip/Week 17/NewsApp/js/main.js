var api_url = 'https://newsapi.org/v2/top-headlines?country=gb&apiKey=d94315de502a4392a91cb3a79483235e';

const Http = new XMLHttpRequest();
const url = api_url;
Http.open("GET", url);
Http.send();


Http.onreadystatechange = function () {

    if (this.readyState == 4 && this.status == 200) {

        var data = JSON.parse(Http.responseText);

        for (article of data.articles) {
            console.log(article.title);


            console.log(data);
            $('#mainContent').before('<h1>Hello World</h1>');

            var currentParent = document.getElementById('mainContent');
            var currentChild = document.createElement('a');
            currentChild.setAttribute('href', article.url);
            currentParent.appendChild(currentChild);

            currentParent = currentChild;
            var currentChild = document.createElement('div');
            currentChild.setAttribute('class', 'col s12');
            currentParent.appendChild(currentChild);

            currentParent = currentChild;
            currentChild = document.createElement('div');
            currentChild.setAttribute('class', 'card');
            currentParent.appendChild(currentChild);

            currentParent = currentChild;
            currentChild = document.createElement('div');
            currentChild.setAttribute('class', 'card-image waves-effect waves-block waves-light');
            currentParent.appendChild(currentChild);

            currentParent = currentChild;
            currentChild = document.createElement('img');
            currentChild.setAttribute('class', 'activator');
            currentChild.setAttribute('src', article.urlToImage);
            currentParent.appendChild(currentChild);

            currentParent = currentParent.parentNode;
            currentChild = document.createElement('div');
            currentChild.setAttribute('class', 'card-content');
            currentParent.appendChild(currentChild);

            currentParent = currentChild;
            currentChild = document.createElement('span');
            currentChild.setAttribute('class', 'card-title activator grey-text text-darken-4');
            currentChild.innerHTML = article.title;
            currentParent.appendChild(currentChild);




        }


    }
}
