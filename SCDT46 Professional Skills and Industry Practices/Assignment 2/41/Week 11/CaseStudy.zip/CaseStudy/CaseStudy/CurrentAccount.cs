﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseStudy
{
    public class CurrentAccount : BankAccount
    {

        public Branch branch;

        public CurrentAccount(int accountnumber, double balance, Branch branch) :base(accountnumber, balance)
        {
         
        }

        private double interestRate = 0.12;

        double calculateCharges()
        {
            return 0;
        }
        double calculateInterest()
        {
            return 0;// returnBalance() * interestRate;
        }
    }
}
