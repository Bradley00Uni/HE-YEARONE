﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseStudy
{
    public class Customer
    {
        private string CustomerName;
        private string CustomerAddress;
        private CurrentAccount myAccount;

        public Customer(string name, string address, CurrentAccount account)
        {
            this.CustomerName = name;
            this.CustomerAddress = address;
            this.myAccount = account;
            
        }

        public void ShowDetails()
        {
            Console.WriteLine("Customer Name: {0}",CustomerName);
            Console.WriteLine("Customer Address: {0}", CustomerAddress);
            Console.WriteLine("Customer Balance: {0}", myAccount);//.ReturnBalance();
        }
    }
}
