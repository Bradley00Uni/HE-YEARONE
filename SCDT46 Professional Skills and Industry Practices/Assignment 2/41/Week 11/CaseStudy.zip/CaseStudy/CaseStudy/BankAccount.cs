﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseStudy
{
    public class BankAccount
    {
        private int accountNo;
        private double balance;

        public BankAccount(int accountno, double balance)
        {
            this.accountNo = accountno;
            this.balance = balance;
        }

        private double interestRate = 0.12;

        //double calculateCharges()
        //{
           // return;
       // }
        double calculateInterest()
        {
            return 0; //returnBalance() * interestRate;
        }


    }
}
