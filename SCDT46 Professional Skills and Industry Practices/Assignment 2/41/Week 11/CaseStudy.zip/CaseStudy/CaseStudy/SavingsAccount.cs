﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseStudy
{
    public class SavingsAccount : BankAccount
    {
        public Branch branch;
        public SavingsAccount(int accountno, double balance, Branch branch): base(accountno,balance)
        {

        }

        private double interestRate = 0.12;

        double calculateCharges()
        {
            return 0;
        }
        double calculateInterest()
        {
            return 0;// returnBalance() * interestRate;
        }
    }
}
