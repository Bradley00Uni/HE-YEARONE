﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            double output = 0;
            char operation_output = char.Parse("0");

            Console.WriteLine("Please enter your first value");
            double first_number = double.Parse(Console.ReadLine());
            Console.WriteLine("Please enter your second value");
            double second_number = double.Parse(Console.ReadLine());
            Console.WriteLine("Please enter your desired operation");
            char operation = char.Parse(Console.ReadLine());

            switch (operation)
            {
                case '+': //chooses which case based on the operation inputted by the user
                    output = first_number + second_number; //adds the two inputted numbers together
                    operation_output = char.Parse("+");
                    break;
                case '-':
                    output = first_number - second_number;
                    operation_output = char.Parse("-");
                    break;
                case '*':
                    output = first_number * second_number;
                    operation_output = char.Parse("x");
                    break;
                case '/':
                    output = first_number / second_number;
                    operation_output = char.Parse("÷"); //sets the operation symbol to be displayed at the end
                    break;
                default:
                    Console.WriteLine("Unknown Operation");
                    break;
            }
            Console.WriteLine("{0} {1} {2} = {3}", first_number, operation_output, second_number, output); //outputs the entire calculation
            Console.ReadLine();

        }
    }
}
