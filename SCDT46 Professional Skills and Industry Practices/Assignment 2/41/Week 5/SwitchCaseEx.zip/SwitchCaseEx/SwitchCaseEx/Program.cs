﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchCaseEx
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            while (i < 1)
            {
                Console.WriteLine("Enter a Number");
                int value = int.Parse(Console.ReadLine());

                switch (value) //Starts the statement, the brackets contain the value that i am testing in the switch                        
                {
                    case 1: //essentially is value == 1
                        Console.WriteLine("Value is 1");
                        break; //breaks out of the switch statement
                    case 2: //essentially is value == 2
                        Console.WriteLine("Value is 2");
                        break;
                    case 3: //essentially is value == 3
                        Console.WriteLine("Value is 3");
                        break;
                    default:
                        Console.WriteLine("This ain't it Chief");
                        break;
                        if(value)
                }
            }
            Console.ReadLine();

        }
    }
}
