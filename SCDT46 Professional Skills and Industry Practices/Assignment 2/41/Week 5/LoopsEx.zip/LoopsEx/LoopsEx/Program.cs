﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoopsEx
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int x = 0; x < 100000000; x++)
            {
                Console.WriteLine("The counter is: {0}", x);
            }
            Console.ReadLine();
        }
    }
}
