﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingTime
{
    class Program
    {
        static void Main(string[] args)
        {
            var submission_date = new DateTime(3, 2, 1);
            var now = DateTime.Now;
            var today = DateTime.Today;

            var tomorrow = now.AddDays(1);
            var yesterday = now.AddDays(-1);

            submission_date = DateTime.Now;
            Console.WriteLine(submission_date);
            Console.WriteLine(tomorrow);
            Console.WriteLine(yesterday);

            

            bool IsRunning = true;
            do
            {
                Console.WriteLine("Please Enter the Nature of your Compaint");
                string title = Console.ReadLine();
                var complaint = new Compaint_Handling();
                complaint.Title = title;
                complaint.LaunchComplaint();
                IsRunning = false;
            } while (IsRunning);

            Console.ReadLine();
        }
    }
}
