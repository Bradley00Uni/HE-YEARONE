﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingTime
{
    class Compaint_Handling
    {
        public string Title;
        public string Name;
        DateTime Submission;
        public string Details;
        public double Phone;

        public void LaunchComplaint()
        {
            Console.WriteLine("What is your Name?");
            Name = Console.ReadLine();
            Console.WriteLine("What is your contact Number?");
            Phone = double.Parse(Console.ReadLine());
            Console.WriteLine("Describe the Complaint");
            Details = Console.ReadLine();
            Submission = DateTime.Now;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Thank You, your complaint has been logged");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
