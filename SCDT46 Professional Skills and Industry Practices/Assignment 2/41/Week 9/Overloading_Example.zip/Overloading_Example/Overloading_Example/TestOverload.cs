﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overloading_Example
{
    public class TestOverload
    {
        public int Test(int a, int b)
        {
            int c = a + b;
            return c;
        }
        public double Test(double a, double b)
        {
            double c = a + b;
            return c;
        }
        public string Test(string a, string b)
        {
            string c = a + " " + b;
            return c;
        } 
        public string Test(int a, string b, double c)
        {
            string d = b + a.ToString() + c.ToString();
            return d;
        }
        public string Test(string a, double b, int c)
        {
            return a;
        }
        public double Test(Object thing)
        {
            double a = 1;
            return a;
        }
        
    }
}
