﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            var numbers = new int[5] {4, 5, 7, 23, 6}; 
            
            Console.WriteLine(numbers[3]); //calls fourth value from the array - as computers count from zero

            //multidimensional array

            var MultiArray = new int[2, 4] { { 34, 2, 12, 34},{ 2, 4, 6, 8} };

            //jagged array

            var jagged = new int[3][];
            //each array index is a new array in jagged
            jagged[0] = new int[4];
            jagged[1] = new int[2];
            jagged[2] = new int[3];

            //putting random values into an array with a loop

            var lotto = new int[7];
            for (int i = 0; i < lotto.Length; i++)
            {
                Random rand = new Random();
                lotto[i] = rand.Next(0, 50);
                Console.WriteLine("Lotto Number: {0}", lotto[i]);
                //currently won't re-generate random number
            }
            Console.ReadLine();
        }
    }
}
