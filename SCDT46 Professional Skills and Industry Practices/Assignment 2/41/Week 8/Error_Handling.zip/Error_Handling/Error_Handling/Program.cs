﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Error_Handling
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                Console.WriteLine("Please Enter First Number...");
                int num1 = int.Parse(Console.ReadLine());
                if (num1 == 0)
                {
                    Console.WriteLine("Incorrect Input");
                    Console.ReadLine();
                    System.Environment.Exit(1);
                }
                Console.WriteLine("Please Enter Second Number...");
                int num2 = int.Parse(Console.ReadLine());
                if (num2 == 0)
                {
                    Console.WriteLine("Incorrect Input");
                    Console.ReadLine();
                    System.Environment.Exit(1);
                }

                double answer = Convert.ToDouble(num1) / Convert.ToDouble(num2);

                Console.WriteLine("Your answer is: {0}", answer);
            }
            catch (FormatException ex)
            {
                string ErrorMessage = ex.ToString();
                Console.WriteLine("Not a Valid Number!");
                Console.WriteLine("Error Shwon:\n\n {0}", ErrorMessage);
            }
            catch (DivideByZeroException ex)
            {
                string ErrorMessage = ex.ToString();
                Console.WriteLine("Cannot Divide");
                Console.WriteLine("Error Shwon:\n\n {0}", ErrorMessage);
            }

            Console.ReadLine();

        }
    }
}
