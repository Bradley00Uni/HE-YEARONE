﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionaries
{
    class Program
    {
        static void Main(string[] args)
        {

            //Creating new Dictionary, with two String types
            Dictionary<string,string> recipes = new Dictionary<string,string>();

            //Adding to the Dictionary
            recipes.Add("Beans on Toast", "Beans, Bread, Butter");
            recipes.Add("Tomato Pasta", "Pasta, Passata, Cheese");
            recipes.Add("Cheese Hamwich", "Bread, Ham, Cheese");

            //Asking user what value they want to search for in the Dictionary
            Console.WriteLine("What Recipe do you need?");
            string request = Console.ReadLine();

            //Searching for value in the Dictionary
            //Validates if the value exists in the Dictionary
            if (recipes.TryGetValue(request, out string example))
            {
                Console.WriteLine("Ingredients Needed: {0}", example);
            }
            else
            {
                Console.WriteLine("Cannot Find Dictionary Value");
            }

            Console.ReadLine();

        }
    }
}
