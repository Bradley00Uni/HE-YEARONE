document.getElementById("student-title").style.display = 'none';
document.getElementById("student").style.display = 'none';

function callWeston() { //When User views Discount information on Weston, this information is displayed-->

    var discountDay = "Monday";

    var firstDiscount = "• 50% off Table Hire <br> • 50% off Snooker & (English, American & Chinese) Pool";

    var secondDiscount = "• 15% off food & drink <br>• +10% credit to the app bank <br>• 50% off Snooker & (English, American & Chinese) Pool";

    document.getElementById("venue-display").innerHTML = "Weston-super-Mare";
    document.getElementById("monday-tuesday").innerHTML = discountDay;
    document.getElementById("first-discount").innerHTML = firstDiscount;
    document.getElementById("second-discount").innerHTML = secondDiscount;
    document.getElementById("student-title").style.display = 'none';
    document.getElementById("student").style.display = 'none';
}

function callTaunton() { //When User views Discount information on Taunton, this information is displayed-->

    var discountDay = "Tuesday";

    var firstDiscount = "• 50% off Table Hire <br> • 50% off Snooker & (English, American & Chinese) Pool";

    var secondDiscount = "• 15% off food & drink <br>• +10% credit to the app bank <br>• 50% off Snooker & (English, American & Chinese) Pool";

    document.getElementById("venue-display").innerHTML = "Taunton";
    document.getElementById("monday-tuesday").innerHTML = discountDay;
    document.getElementById("first-discount").innerHTML = firstDiscount;
    document.getElementById("second-discount").innerHTML = secondDiscount;
    document.getElementById("student-title").style.display = 'none';
    document.getElementById("student").style.display = 'none';
}

function callBristol() { //When User views Discount information on Bristol, this information is displayed-->

    var discountDay = "Tuesday";

    var firstDiscount = "• 50% off Table Hire <br> • 50% off Snooker & (English, American & Chinese) Pool";

    var secondDiscount = "• 15% off food & drink <br>• +10% credit to the app bank <br>• 50% off Snooker & (English, American & Chinese) Pool";

    document.getElementById("venue-display").innerHTML = "Bristol";
    document.getElementById("monday-tuesday").innerHTML = discountDay;
    document.getElementById("first-discount").innerHTML = firstDiscount;
    document.getElementById("second-discount").innerHTML = secondDiscount;
    document.getElementById("student-title").style.display = 'block';
    document.getElementById("student").style.display = 'block';
}

function callExeter() { //When User views Discount information on Exeter, this information is displayed-->

    var discountDay = "Tuesday";

    var firstDiscount = "• 50% off Table Hire <br> • 50% off Snooker & (English, American & Chinese) Pool";

    var secondDiscount = "• 15% off food & drink <br>• +10% credit to the app bank <br>• 50% off Snooker & (English, American & Chinese) Pool";

    document.getElementById("venue-display").innerHTML = "Exeter";
    document.getElementById("monday-tuesday").innerHTML = discountDay;
    document.getElementById("first-discount").innerHTML = firstDiscount;
    document.getElementById("second-discount").innerHTML = secondDiscount;
    document.getElementById("student-title").style.display = 'block';
    document.getElementById("student").style.display = 'block';
}
